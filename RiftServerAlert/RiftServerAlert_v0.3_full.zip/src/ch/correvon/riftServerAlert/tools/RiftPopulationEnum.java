package ch.correvon.riftServerAlert.tools;

public enum RiftPopulationEnum
{
	low,
	medium,
	high;
}
