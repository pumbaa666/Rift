package ch.correvon.rift.riftParsing.use;

import java.io.File;
import java.net.URI;
import java.net.URISyntaxException;

import ch.correvon.rift.riftParsing.item.GenerateItemSql;
import ch.correvon.rift.riftParsing.item.ItemHandler;
import ch.correvon.rift.riftParsing.recipe.GenerateRecipeSql;
import ch.correvon.rift.riftParsing.recipe.RecipeHandler;
import ch.correvon.rift.riftParsing.xml.XMLParser;

import org.xml.sax.SAXException;

public class MainRiftParser
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		int i = 0;
		int nbArg = args.length;
		if(nbArg == 0)
			printHelp();
		for(String arg:args)
		{
			if(arg.equals("-h"))
				printHelp();
			if(arg.equals("-i") && i < nbArg)
				generateItemSql(args[i+1]);
			if(arg.equals("-r") && i < nbArg)
				generateRecipeSql(args[i+1]);
			i++;
		}
	}
	
	public static void generateItemSql(String fileName)
	{
		fileName = checkFileName(fileName);
		if(fileName == null)
			return;
		
		ItemHandler itemHandler = (ItemHandler)XMLParser.readXML(fileName, ItemHandler.class);
		
		try
		{
			GenerateItemSql.generateSql(itemHandler.getItems(), "insertItem.sql");
		}
		catch(SAXException e)
		{
			e.printStackTrace();
		}
	}
	
	public static void generateRecipeSql(String fileName)
	{
		fileName = checkFileName(fileName);
		if(fileName == null)
			return;
		
		RecipeHandler itemHandler = (RecipeHandler)XMLParser.readXML(fileName, RecipeHandler.class);
		
		try
		{
			GenerateRecipeSql.generateSql(itemHandler.getRecipes(), "insertRecipe.sql");
		}
		catch(SAXException e)
		{
			e.printStackTrace();
		}
	}
	
	private static String checkFileName(String fileName)
	{
//		String adresse = "file:///C:/Program Files/EasyPHP/www/php/RiftForum/RiftWeb/data/Rift_Discoveries/Items.xml";
//		String adresse = "file:///D:/Projects/MyProjects_ws/RiftParsing/test1.xml";
		if(fileName == null || fileName.isEmpty())
		{
			printHelp();
			return null;
		}
		
		File file = new File(fileName);
		if(file.exists())
			fileName = file.toURI().toString();
		else
		{
			try
			{
				file = new File(new URI(fileName));
				if(!file.exists())
					new URI(":::"); // Rise an URISyntaxException to show error
			}
			catch(URISyntaxException e)
			{
				System.err.println("Impossible de trouver le fichier "+fileName);
				e.printStackTrace();
				return null;
			}
		}
		return fileName;
	}
	
	private static void printHelp()
	{
		System.out.println("RiftParsing v0.2 cod� par Pumbaa");
		System.out.println("Usage : java -jar riftParsing0.1.jar [-i RIFT_ITEM_FILENAME.xml]");
	}
}
