package ch.correvon.rift.riftParsing.item.enumeration;

import java.util.ArrayList;
import java.util.List;

import ch.correvon.rift.riftParsing.subObject.A_MyEnum;

import org.xml.sax.SAXException;


public class RuneAllowedSlots extends A_MyEnum
{
	public static final A_MyEnum GLOVES = new RuneAllowedSlots(1, "Gloves");
	public static final A_MyEnum WEAPON_2H = new RuneAllowedSlots(2, "Weapon_2h");
	public static final A_MyEnum FEET = new RuneAllowedSlots(3, "Feet");
	public static final A_MyEnum CHEST = new RuneAllowedSlots(4, "Chest");
	public static final A_MyEnum SHOULDERS = new RuneAllowedSlots(5, "Shoulders");
	public static final A_MyEnum PANTS = new RuneAllowedSlots(6, "Pants");
	public static final A_MyEnum BELT = new RuneAllowedSlots(7, "Belt");
	public static final A_MyEnum LEGS = new RuneAllowedSlots(8, "Legs");
	public static final A_MyEnum WEAPON_MAIN = new RuneAllowedSlots(9, "Weapon_Main");
	public static final A_MyEnum HELMET = new RuneAllowedSlots(10, "Helmet");
	public static final A_MyEnum WEAPON_RANGED = new RuneAllowedSlots(11, "Weapon_Ranged");
	
		
	private static final List<A_MyEnum> list = new ArrayList<A_MyEnum>(10);
	
	static
	{
		list.add(GLOVES);
		list.add(WEAPON_2H);
		list.add(FEET);
		list.add(CHEST);
		list.add(SHOULDERS);
		list.add(PANTS);
		list.add(BELT);
		list.add(LEGS);
		list.add(WEAPON_MAIN);
		list.add(HELMET);
		list.add(WEAPON_RANGED);
	}
	
	public RuneAllowedSlots(int value, String name)
	{
		super(value, name);
	}

	public static A_MyEnum getEnum(String stringValue) throws SAXException
	{
		for(A_MyEnum myEnum:list)
			if(myEnum.getName().equals(stringValue))
				return myEnum;
		throw new SAXException("Enum�ration "+stringValue+" non trouv�e");
	}
}
