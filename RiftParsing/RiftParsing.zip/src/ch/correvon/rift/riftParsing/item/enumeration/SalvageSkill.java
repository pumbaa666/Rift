package ch.correvon.rift.riftParsing.item.enumeration;

import java.util.ArrayList;
import java.util.List;

import ch.correvon.rift.riftParsing.subObject.A_MyEnum;

import org.xml.sax.SAXException;


public class SalvageSkill extends A_MyEnum
{
	public static final A_MyEnum ARTIFICER = new SalvageSkill(1, "Artificer");
	
	private static final List<A_MyEnum> list = new ArrayList<A_MyEnum>(1);
	
	static
	{
		list.add(ARTIFICER);
	}
	
	public SalvageSkill(int value, String name)
	{
		super(value, name);
	}

	public static A_MyEnum getEnum(String stringValue) throws SAXException
	{
		for(A_MyEnum myEnum:list)
			if(myEnum.getName().equals(stringValue))
				return myEnum;
		throw new SAXException("Enum�ration "+stringValue+" non trouv�e");
	}
}
