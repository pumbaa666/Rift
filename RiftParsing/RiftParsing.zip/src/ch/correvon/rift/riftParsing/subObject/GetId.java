package ch.correvon.rift.riftParsing.subObject;

public interface GetId
{
	public String getId();
}
