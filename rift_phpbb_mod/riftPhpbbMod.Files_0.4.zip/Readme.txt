Show http://forums.riftgame.fr/discussions-generales-rift/nouvelles-des-sites-de-fans/9465-mod-pour-phpbb3.html
for full tutorial.

Or contact pumbaa@net2000.ch