package ch.correvon.rift.macro.use;

import ch.correvon.rift.macro.windows.mainWindow.MainWindow;

public class MainRiftMacro
{
	public static void main(String[] args)
	{
		new MainWindow().run();
	}
}
