package ch.correvon.rift.macro.robots;

import java.awt.Color;
import java.awt.MouseInfo;
import java.awt.Point;

import ch.correvon.rift.macro.windows.mainWindow.MainWindow;

public class Robot1 extends _RobotExecutor
{
	public Robot1(String name, MainWindow mainWindow)
	{
		super(name, mainWindow);
	}
	
	@Override public void execute()
	{
		int i = 0;
		while(i++ < 5)
		{
			Point point = MouseInfo.getPointerInfo().getLocation();
			Color color = super.getPixelColor(point);
			super.printLog("x = " + point.x + ", y = " + point.y + " / color : [r = " + color.getRed() + ", g = " + color.getGreen() + ", b = " + color.getBlue() + "]");
			
			try
			{
				super.sleep(500);
			}
			catch(InterruptedException e)
			{
				e.printStackTrace();
			}
		}
	}
	
	@Override public void exit()
	{
		
	}
}
