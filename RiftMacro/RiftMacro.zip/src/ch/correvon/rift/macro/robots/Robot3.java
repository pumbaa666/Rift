package ch.correvon.rift.macro.robots;

import ch.correvon.rift.macro.windows.mainWindow.MainWindow;


public class Robot3 extends _RobotExecutor
{
	public Robot3(String name, MainWindow mainWindow)
	{
		super(name, mainWindow);
	}

	@Override public void execute()
	{
		while(!this.exit)
		{
			super.printLog("Et on fait tourner les serviettes !!!");
			try
			{
				super.sleep(1000);
			}
			catch(InterruptedException e)
			{
				e.printStackTrace();
			}
		}
		super.printLog("Dis au revoir !");
	}

	@Override public void exit()
	{
		this.exit = true;
		super.printLog("kkkrrrshshhshhs - on demande l'extinction du robot");
	}
	
	private boolean exit = false;
}
