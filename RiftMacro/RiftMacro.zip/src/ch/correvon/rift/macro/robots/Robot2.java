package ch.correvon.rift.macro.robots;

import ch.correvon.rift.macro.windows.mainWindow.MainWindow;
import de.ksquared.system.keyboard.KeyEvent;


public class Robot2 extends _RobotExecutor
{
	public Robot2(String name, MainWindow mainWindow)
	{
		super(name, mainWindow);
	}

	@Override public void execute()
	{
		super.printLog("do the robot dance");
		super.hitKeySafe(KeyEvent.VK_2);
	}

	@Override public void exit()
	{
		
	}
}
