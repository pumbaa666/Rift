package ch.correvon.rift.macro.robots;

import ch.correvon.rift.macro.windows.mainWindow.MainWindow;


public class Robot5 extends _RobotExecutor
{
	public Robot5(String name, MainWindow mainWindow)
	{
		super(name, mainWindow);
	}

	@Override public void execute()
	{
		super.printLog("le 5ème élement");
	}

	@Override public void exit()
	{
		
	}
}
