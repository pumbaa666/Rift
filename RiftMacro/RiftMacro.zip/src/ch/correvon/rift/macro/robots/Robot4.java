package ch.correvon.rift.macro.robots;

import ch.correvon.rift.macro.windows.mainWindow.MainWindow;


public class Robot4 extends _RobotExecutor
{
	public Robot4(String name, MainWindow mainWindow)
	{
		super(name, mainWindow);
	}

	@Override public void execute()
	{
	}

	@Override public void exit()
	{
		
	}
}
